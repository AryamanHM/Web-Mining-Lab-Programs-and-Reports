<div style="text-align:center;">
<img src="https://github.com/wesdoyle/Javelin.NET/blob/master/Javelin.png" width="300px">
</div>

# Javelin
Information Retrieval patterns using .NET
