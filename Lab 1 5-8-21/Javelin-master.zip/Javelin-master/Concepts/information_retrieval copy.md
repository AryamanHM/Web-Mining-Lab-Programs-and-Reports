# Information Retrieval (Search)

> Information Retrieval (IR) is finding material (usually documents) of an unstructured nature (usually text) that satisfies an information need from within large collections (usually stored on computers)
> - Introduction to Information Retrieval, Manning, Raghavan, Schütze
