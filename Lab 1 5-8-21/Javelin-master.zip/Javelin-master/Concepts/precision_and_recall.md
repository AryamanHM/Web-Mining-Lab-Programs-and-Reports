# Precision vs. Recall 

__Precision__: What percentage of the results returned by the search engine are relevant to the search topic? 

__Recall__: What percentage of the documents that are relevant to the search topic are returned by the search engine?