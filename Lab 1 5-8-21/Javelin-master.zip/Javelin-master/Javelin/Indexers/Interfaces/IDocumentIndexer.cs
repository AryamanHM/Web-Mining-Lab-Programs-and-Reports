namespace Javelin.Indexers.Interfaces {
    public interface IDocumentIndexer {
    }
}