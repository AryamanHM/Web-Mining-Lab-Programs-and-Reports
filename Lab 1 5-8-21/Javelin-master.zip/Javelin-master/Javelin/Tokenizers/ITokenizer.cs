namespace Javelin.Tokenizers {
    public interface ITokenizer {
        string[] Tokenize(string text);
    }
}